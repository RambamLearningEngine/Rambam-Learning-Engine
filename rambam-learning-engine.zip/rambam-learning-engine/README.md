
# Rambam Learning Engine

Simple React app for learning the 14 books of Mishneh Torah.

## Run locally

```bash
npm install
npm run dev
```

Replace `src/App.jsx` in a Vite React project with the included App.jsx file.
