import React, { useMemo, useState } from "react";

const BOOKS = [
  { n: 1, hebrew: "ספר המדע", shortHebrew: "מדע", english: "Knowledge", translit: "Madda" },
  { n: 2, hebrew: "ספר אהבה", shortHebrew: "אהבה", english: "Love", translit: "Ahavah" },
  { n: 3, hebrew: "ספר זמנים", shortHebrew: "זמנים", english: "Times", translit: "Zemanim" },
  { n: 4, hebrew: "ספר נשים", shortHebrew: "נשים", english: "Women", translit: "Nashim" },
  { n: 5, hebrew: "ספר קדושה", shortHebrew: "קדושה", english: "Holiness", translit: "Kedushah" },
  { n: 6, hebrew: "ספר הפלאה", shortHebrew: "הפלאה", english: "Utterances", translit: "Hafla'ah" },
  { n: 7, hebrew: "ספר זרעים", shortHebrew: "זרעים", english: "Seeds", translit: "Zera'im" },
  { n: 8, hebrew: "ספר עבודה", shortHebrew: "עבודה", english: "Temple Service", translit: "Avodah" },
  { n: 9, hebrew: "ספר קרבנות", shortHebrew: "קרבנות", english: "Offerings", translit: "Korbanot" },
  { n: 10, hebrew: "ספר טהרה", shortHebrew: "טהרה", english: "Purity", translit: "Taharah" },
  { n: 11, hebrew: "ספר נזיקין", shortHebrew: "נזיקין", english: "Damages", translit: "Nezikin" },
  { n: 12, hebrew: "ספר קנין", shortHebrew: "קנין", english: "Acquisition", translit: "Kinyan" },
  { n: 13, hebrew: "ספר משפטים", shortHebrew: "משפטים", english: "Judgments", translit: "Mishpatim" },
  { n: 14, hebrew: "ספר שופטים", shortHebrew: "שופטים", english: "Judges", translit: "Shoftim" },
];

export default function App() {
  return (
    <div style={{fontFamily:"Arial",padding:20}}>
      <h1>Rambam Learning Engine</h1>
      <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:12}}>
        {BOOKS.map((book)=>(
          <div key={book.n} style={{border:"1px solid #ddd",borderRadius:12,padding:12}}>
            <div style={{fontWeight:"bold"}}>#{book.n}</div>
            <div dir="rtl" style={{fontSize:24,fontWeight:"bold"}}>{book.hebrew}</div>
            <div>{book.english}</div>
            <div style={{color:"#666"}}>{book.translit}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
